<div class="copyright-wrapper">
    <div class="copyright-area">
        <p>{{ __("Developed by") }} <a href="https://appdevs.net">AppDevs.</a></p>
        <p>{{ $basic_settings->site_name }} <span>{{ __("V") }}{{ $basic_settings->web_version  }}</span></p>
    </div>
</div>
